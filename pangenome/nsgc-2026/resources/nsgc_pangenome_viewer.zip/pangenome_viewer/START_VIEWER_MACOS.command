#!/bin/bash

cd -- "$(dirname -- "$0")" || exit 1

PORT=8080
URL="http://127.0.0.1:${PORT}/index.html?v=4"

echo "Pangenome SegDup/SV Viewer"
echo "Serving: $(pwd)"
echo

if [[ ! -f index.html || ! -f serve_viewer.py ]]; then
    echo "ERROR: index.html or serve_viewer.py is missing from this folder."
    read -r -p "Press Return to close..."
    exit 1
fi

if ! command -v python3 >/dev/null 2>&1 ||
    ! python3 -c "import http.server" >/dev/null 2>&1; then
    echo "Python 3 is required but was not found."

    if command -v brew >/dev/null 2>&1; then
        echo "Homebrew is available and can install Python 3."
        read -r -p "Install Python 3 now? [y/N] " answer
        case "${answer}" in
            y|Y|yes|YES)
                echo "Installing Python 3 with Homebrew..."
                if ! brew install python; then
                    echo "ERROR: Homebrew could not install Python 3."
                    read -r -p "Press Return to close..."
                    exit 1
                fi
                hash -r
                ;;
            *)
                echo "Installation cancelled."
                read -r -p "Press Return to close..."
                exit 1
                ;;
        esac
    else
        echo
        echo "Homebrew is not installed, so this launcher will not modify"
        echo "the Mac by installing a package manager."
        echo
        echo "Install Python 3 from:"
        echo "  https://www.python.org/downloads/macos/"
        echo
        echo "No pip packages are required."
        read -r -p "Press Return to open the Python download page, or Ctrl-C to cancel..."
        open "https://www.python.org/downloads/macos/"
        exit 1
    fi
fi

if ! command -v python3 >/dev/null 2>&1 ||
    ! python3 -c "import http.server" >/dev/null 2>&1; then
    echo "ERROR: Python 3 was installed but is not yet usable."
    echo "Close this window and run the launcher again."
    read -r -p "Press Return to close..."
    exit 1
fi

if ! python3 -c "import socket,sys; s=socket.socket(); s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1); s.bind(('127.0.0.1',int(sys.argv[1]))); s.close()" "${PORT}" >/dev/null 2>&1; then
    echo "ERROR: Port ${PORT} is already in use."
    echo "Close the older viewer Terminal window, then try again."
    read -r -p "Press Return to close..."
    exit 1
fi

echo "Keep this Terminal window open while using the viewer."
echo "Browser URL: ${URL}"
echo

open_when_ready() {
    for _ in {1..60}; do
        if python3 -c "import socket,sys; s=socket.create_connection(('127.0.0.1',int(sys.argv[1])),0.5); s.close()" "${PORT}" >/dev/null 2>&1; then
            open "${URL}"
            return
        fi
        sleep 0.5
    done
    echo "ERROR: The local server did not become ready."
}

open_when_ready &
python3 serve_viewer.py --port "${PORT}" --bind 127.0.0.1

echo
echo "The server stopped."
read -r -p "Press Return to close..."

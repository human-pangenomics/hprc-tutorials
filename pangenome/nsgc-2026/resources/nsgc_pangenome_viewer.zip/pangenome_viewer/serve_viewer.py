#!/usr/bin/env python3
"""Local HTTP server for the Pangenome Viewer."""

import argparse
import http.server
import os
import re
import socketserver
import sys
from urllib.parse import urlsplit


class ViewerRequestHandler(http.server.SimpleHTTPRequestHandler):
    """Cache versioned genomic data while keeping the application current."""

    _range = None

    def end_headers(self):
        path = urlsplit(self.path).path
        if path.startswith("/bams/"):
            self.send_header("Cache-Control", "public, max-age=31536000, immutable")
            self.send_header("Accept-Ranges", "bytes")
        else:
            self.send_header("Cache-Control", "no-store, no-cache, must-revalidate")
            self.send_header("Pragma", "no-cache")
            self.send_header("Expires", "0")
        super().end_headers()

    def send_head(self):
        self._range = None
        range_header = self.headers.get("Range")
        if not range_header:
            return super().send_head()

        path = self.translate_path(self.path)
        if os.path.isdir(path):
            return super().send_head()

        match = re.fullmatch(r"bytes=(\d*)-(\d*)", range_header.strip())
        if not match:
            self.send_error(416, "Invalid byte range")
            return None

        try:
            source = open(path, "rb")
        except OSError:
            self.send_error(404, "File not found")
            return None

        size = os.fstat(source.fileno()).st_size
        start_text, end_text = match.groups()
        if start_text:
            start = int(start_text)
            end = int(end_text) if end_text else size - 1
        elif end_text:
            suffix_length = int(end_text)
            start = max(size - suffix_length, 0)
            end = size - 1
        else:
            source.close()
            self.send_error(416, "Invalid byte range")
            return None

        if start >= size or start > end:
            source.close()
            self.send_response(416)
            self.send_header("Content-Range", "bytes */{}".format(size))
            self.end_headers()
            return None

        end = min(end, size - 1)
        length = end - start + 1
        self._range = (start, end)
        source.seek(start)

        self.send_response(206)
        self.send_header("Content-Type", self.guess_type(path))
        self.send_header("Content-Range", "bytes {}-{}/{}".format(start, end, size))
        self.send_header("Content-Length", str(length))
        self.send_header(
            "Last-Modified",
            self.date_time_string(os.fstat(source.fileno()).st_mtime),
        )
        self.end_headers()
        return source

    def copyfile(self, source, outputfile):
        if self._range is None:
            return super().copyfile(source, outputfile)

        remaining = self._range[1] - self._range[0] + 1
        while remaining:
            chunk = source.read(min(64 * 1024, remaining))
            if not chunk:
                break
            outputfile.write(chunk)
            remaining -= len(chunk)


class ViewerHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    """Suppress harmless disconnect tracebacks from browser preconnections."""

    daemon_threads = True
    allow_reuse_address = True

    def handle_error(self, request, client_address):
        error = sys.exc_info()[1]
        if isinstance(
            error,
            (BrokenPipeError, ConnectionAbortedError, ConnectionResetError),
        ):
            return
        super().handle_error(request, client_address)


def main():
    parser = argparse.ArgumentParser(description="Serve the Pangenome Viewer locally.")
    parser.add_argument("--bind", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8080)
    args = parser.parse_args()

    handler = ViewerRequestHandler
    with ViewerHTTPServer((args.bind, args.port), handler) as server:
        print(
            "Serving HTTP on {} port {} (http://{}:{}/) ...".format(
                args.bind, args.port, args.bind, args.port
            ),
            flush=True,
        )
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            print("\nServer stopped.")


if __name__ == "__main__":
    main()

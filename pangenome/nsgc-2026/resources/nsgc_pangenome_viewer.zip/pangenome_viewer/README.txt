Pangenome SegDup/SV Viewer

QUICK START

Keep index.html, serve_viewer.py, the platform launchers, and the bams
folder together. Do not open index.html directly.

Windows:

1. Unzip the complete folder.
2. Double-click START_VIEWER_WINDOWS.bat.
3. Keep the command window open while using the viewer.

macOS:

1. Unzip the complete folder.
2. Double-click START_VIEWER_MACOS.command.
3. Keep the Terminal window open while using the viewer.

If macOS blocks the launcher, Control-click it, choose Open, and confirm.
If it is not executable, open Terminal in this folder and run:

  bash START_VIEWER_MACOS.command

Linux:

1. Unzip the complete folder.
2. Open a terminal in this folder and run:

  bash START_VIEWER_LINUX.sh

3. Keep the terminal open while using the viewer.

The browser normally opens automatically. If it does not, open:

  http://127.0.0.1:8080/index.html

Use the SNV and SV buttons at the top to switch modes.

One index.html contains two modes:
- SV: one IGV panel
- SNV: two synchronized IGV panels

Requirements:
- Python 3
- A modern web browser
- An internet connection (IGV.js and the hg38 genome are loaded online)

No pip, npm, or other Python packages are required. The launchers use
only Python's standard library. Each launcher checks for Python 3.
The local server keeps versioned genomic data in the browser cache to
speed up repeat launches, while index.html is always refreshed.
If it is missing, the launcher asks for permission before installing:
- Windows: winget
- macOS: Homebrew, when Homebrew is already installed
- Linux: apt, dnf, yum, zypper, or pacman

Installation is never silent. Administrator approval may be requested.
If a supported package manager is unavailable, the launcher provides
manual installation instructions instead.

Files:
- index.html: complete viewer with the two mode buttons
- serve_viewer.py: local-only web server used by all three launchers
- bams/: BAM, BAI, VCF, TBI, and local GENCODE v49 data
- START_VIEWER_WINDOWS.bat: Windows launcher
- START_VIEWER_MACOS.command: macOS double-click launcher
- START_VIEWER_LINUX.sh: Linux launcher

Platform notes:

Windows:

The launcher starts in its own folder, so it does not depend on a
particular drive letter or username.

If Python 3 is missing and winget is available, the Windows launcher
asks before installing Python. If winget is unavailable, it opens the
official Python download page.

macOS:

The bash fallback is sometimes needed when the zip was created on Windows,
because Windows zip tools may not preserve the executable permission.

If Python 3 is missing and Homebrew is installed, the launcher offers
to install Python after asking for confirmation.

If Homebrew is not installed, the launcher opens:

  https://www.python.org/downloads/macos/

The launcher intentionally does not install Homebrew itself. Installing
a package manager is a larger system change and may require administrator
approval or be blocked on managed corporate Macs.

Linux:

If Python 3 is missing, the Linux launcher detects apt, dnf, yum,
zypper, or pacman and asks before installing. It may request the
administrator password through sudo.

The Linux launcher uses xdg-open to open the browser when it is
available. Otherwise, use the manual address shown in QUICK START.

The SNV viewer is displayed first. The SV viewer is then preloaded in
the background so switching modes is faster.
The active mode and active preset are highlighted in green. Clicking
an alignment, coverage, variant, or annotation feature opens its IGV
details popup.

SNV presets:

1. LILRA6 vs LILRB3
   LILRA6: chr19:54,240,382-54,240,582
   LILRB3: chr19:54,220,636-54,220,836

2. SIGLEC11 vs SIGLEC16 (reverse-complement synchronized)
   SIGLEC11: chr19:49,960,414-49,960,713
   SIGLEC16: chr19:49,970,032-49,970,328

The merged Pangenome and Linear SNV BAMs contain the complete
chr19:49,959,500-49,971,200 source interval for the SIGLEC comparison.

The following indexed SNV VCF subsets are packaged in bams/ but are
not currently loaded into IGV:
- linear.subset.snv.vcf.gz and .tbi
- pangenome.subset.snv.vcf.gz and .tbi

These VCFs are limited to the four SNV preset windows listed above.

SV presets:

1. STK11: chr19:1,192,000-1,201,000
2. ANKRD11: chr16:89,397,000-89,399,000

SV tracks from top to bottom:

1. Linear SV variants
2. Pangenome SV variants
3. HG002 Q100 hap1 assembly
4. HG002 Q100 hap2 assembly
5. Linear alignments
6. Pangenome alignments
7. GENCODE v49 gene annotations

The SV view uses GENCODE v49 instead of RefSeq All. Its longer STK11
transcript spans the STK11 preset and displays the gene line in that
region. A 2-transcript BED12 subset is packaged locally as
bams/gencodeV49.demo.bed:
- ANKRD11 MANE Select transcript ENST00000301030.10
- STK11 transcript ENST00000585748.3, which spans the demo window

The Linear SV variants file intentionally contains no records in the
two demo regions. Its empty track is retained to show the comparison
with the Pangenome SV calls.
Both packaged SV VCFs were generated by DRAGEN 4.7 and retain the
source sample name NA24385 (HG002). The Pangenome VCF contains one
record in each SV preset region.

External resources:
- IGV.js 3.8.10 is loaded from jsDelivr with a fixed version and
  integrity check.
- The hg38 genome configuration and reference data are loaded by IGV.
- The packaged GENCODE v49 subset was extracted from the UCSC BigBed:
  https://hgdownload.soe.ucsc.edu/gbdb/hg38/gencode/gencodeV49.bb

The packaged alignments and variants use the public HG002 sample.
Internal processing paths and command lines have been removed from
the distributed BAM and VCF headers.

Troubleshooting:

If no pileup is displayed:
1. Confirm the BAM/BAI/VCF files are in the bams folder.
2. Confirm you launched the viewer using the launcher for your OS.
3. Open browser Developer Tools and check for 404 or failed-to-load errors.

If the launcher reports that port 8080 is already in use, close the
previous viewer command/Terminal window and try again.

If the browser reports ERR_CONNECTION_REFUSED:
1. Confirm the launcher command/Terminal window is still open.
2. Check that it says the server is running on 127.0.0.1 port 8080.
3. Read any Python or permission error shown in that window.
4. Restart the correct platform launcher; it waits for the server before
   opening the browser.

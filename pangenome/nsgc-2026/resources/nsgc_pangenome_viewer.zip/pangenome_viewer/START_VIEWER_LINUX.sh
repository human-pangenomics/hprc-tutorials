#!/bin/bash

cd -- "$(dirname -- "$0")" || exit 1

PORT=8080
URL="http://127.0.0.1:${PORT}/index.html?v=4"

echo "Pangenome SegDup/SV Viewer"
echo "Serving: $(pwd)"
echo

if [[ ! -f index.html || ! -f serve_viewer.py ]]; then
    echo "ERROR: index.html or serve_viewer.py is missing from this folder."
    exit 1
fi

if ! command -v python3 >/dev/null 2>&1 ||
    ! python3 -c "import http.server" >/dev/null 2>&1; then
    echo "Python 3 is required but was not found."

    PACKAGE_MANAGER=""
    for candidate in apt-get dnf yum zypper pacman; do
        if command -v "${candidate}" >/dev/null 2>&1; then
            PACKAGE_MANAGER="${candidate}"
            break
        fi
    done

    if [[ -z "${PACKAGE_MANAGER}" ]]; then
        echo "No supported package manager was found."
        echo "Install Python 3 manually, then run this launcher again."
        exit 1
    fi

    read -r -p "Install Python 3 using ${PACKAGE_MANAGER}? [y/N] " answer
    case "${answer}" in
        y|Y|yes|YES) ;;
        *)
            echo "Installation cancelled."
            exit 1
            ;;
    esac

    if [[ "$(id -u)" -eq 0 ]]; then
        SUDO=""
    elif command -v sudo >/dev/null 2>&1; then
        SUDO="sudo"
    else
        echo "Administrator access is required, but sudo was not found."
        exit 1
    fi

    case "${PACKAGE_MANAGER}" in
        apt-get)
            ${SUDO} apt-get update &&
                ${SUDO} apt-get install -y python3
            ;;
        dnf)
            ${SUDO} dnf install -y python3
            ;;
        yum)
            ${SUDO} yum install -y python3
            ;;
        zypper)
            ${SUDO} zypper --non-interactive install python3
            ;;
        pacman)
            ${SUDO} pacman -S --needed --noconfirm python
            ;;
    esac

    if ! command -v python3 >/dev/null 2>&1 ||
        ! python3 -c "import http.server" >/dev/null 2>&1; then
        echo "ERROR: Python 3 installation did not complete successfully."
        exit 1
    fi
fi

if ! python3 -c "import socket,sys; s=socket.socket(); s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1); s.bind(('127.0.0.1',int(sys.argv[1]))); s.close()" "${PORT}" >/dev/null 2>&1; then
    echo "Port ${PORT} is already in use. Close the older viewer server first."
    exit 1
fi

echo "Keep this Terminal window open while using the viewer."
echo "Browser URL: ${URL}"
echo

open_when_ready() {
    for _ in {1..60}; do
        if python3 -c "import socket,sys; s=socket.create_connection(('127.0.0.1',int(sys.argv[1])),0.5); s.close()" "${PORT}" >/dev/null 2>&1; then
            if command -v xdg-open >/dev/null 2>&1; then
                xdg-open "${URL}" >/dev/null 2>&1
            else
                echo "Open ${URL} in a browser."
            fi
            return
        fi
        sleep 0.5
    done
    echo "ERROR: The local server did not become ready."
}

open_when_ready &
python3 serve_viewer.py --port "$PORT" --bind 127.0.0.1

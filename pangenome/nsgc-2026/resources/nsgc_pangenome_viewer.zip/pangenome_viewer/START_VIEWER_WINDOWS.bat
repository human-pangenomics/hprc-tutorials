@echo off
setlocal

cd /d "%~dp0"

set PORT=8080
set URL=http://127.0.0.1:%PORT%/index.html?v=4

echo Pangenome SegDup/SV Viewer
echo Serving: %CD%
echo.
if not exist index.html (
    echo ERROR: index.html is missing.
    pause
    exit /b 1
)
if not exist serve_viewer.py (
    echo ERROR: serve_viewer.py is missing.
    pause
    exit /b 1
)

netstat -ano | findstr /R /C:":%PORT% .*LISTENING" >nul
if %errorlevel%==0 (
    echo ERROR: Port %PORT% is already in use by an older server.
    echo Close the other viewer window or stop its Python process,
    echo then run this file again.
    pause
    exit /b 1
)

py -3 -c "import http.server" >nul 2>nul
if %errorlevel%==0 (
    set PYTHON=py -3
    goto :start
)

python -c "import http.server" >nul 2>nul
if %errorlevel%==0 (
    set PYTHON=python
    goto :start
)

echo Python 3 is required but was not found.
where winget >nul 2>nul
if not %errorlevel%==0 (
    echo.
    echo Windows Package Manager ^(winget^) is not available.
    echo Install Python 3 from https://www.python.org/downloads/windows/
    start "" "https://www.python.org/downloads/windows/"
    pause
    exit /b 1
)

echo Windows Package Manager can install Python 3.
set /p INSTALL_PYTHON="Install Python 3 now? [y/N] "
if /I not "%INSTALL_PYTHON%"=="Y" (
    echo Installation cancelled.
    pause
    exit /b 1
)

echo Installing Python 3...
winget install --id Python.Python.3.13 --exact --accept-package-agreements --accept-source-agreements
if not %errorlevel%==0 (
    echo ERROR: winget could not install Python 3.
    pause
    exit /b 1
)

if exist "%LOCALAPPDATA%\Programs\Python\Launcher\py.exe" (
    set PYTHON="%LOCALAPPDATA%\Programs\Python\Launcher\py.exe" -3
    goto :start
)

if exist "%LOCALAPPDATA%\Programs\Python\Python313\python.exe" (
    set PYTHON="%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
    goto :start
)

echo Python 3 was installed successfully.
echo Close this window and start the viewer again to refresh PATH.
pause
exit /b 0

:start
echo Keep this window open while using the viewer.
echo Browser URL: %URL%
echo.

start "" powershell.exe -NoProfile -WindowStyle Hidden -Command "$url='%URL%'; for ($i=0; $i -lt 60; $i++) { $client=New-Object System.Net.Sockets.TcpClient; try { $client.Connect('127.0.0.1',%PORT%); if ($client.Connected) { $client.Close(); Start-Process $url; exit 0 } } catch {} finally { $client.Dispose() }; Start-Sleep -Milliseconds 500 }"

%PYTHON% serve_viewer.py --port %PORT% --bind 127.0.0.1
echo.
echo The server stopped.
echo If you saw "address already in use", close the older viewer window first.
pause
endlocal
